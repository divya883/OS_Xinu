/* policy.c = srpolicy*/

#include <conf.h>
#include <kernel.h>
#include <paging.h>


extern int page_replace_policy;
/*-------------------------------------------------------------------------
 * srpolicy - set page replace policy 
 *-------------------------------------------------------------------------
 */
SYSCALL srpolicy(int policy)
{

  //As indicated in readme, if this function is called: Enable dbg and Set policy
  STATWORD ps;
  disable(ps);

  if(policy == SC){
    page_replace_policy = SC;
    sc_debug = 1;
    restore(ps);
    return OK;
  }
  restore(ps);
  return SYSERR;

  return OK;
}

/*-------------------------------------------------------------------------
 * grpolicy - get page replace policy 
 *-------------------------------------------------------------------------
 */
SYSCALL grpolicy()
{
  return page_replace_policy;
}
