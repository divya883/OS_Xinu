/* pfint.c - pfint */

#include <conf.h>
#include <kernel.h>
#include <paging.h>
#include <proc.h>

/*-------------------------------------------------------------------------
 * pfint - paging fault ISR
 *-------------------------------------------------------------------------
 */
SYSCALL pfint()
{
	STATWORD ps;
	disable(ps);
	unsigned long vaddr = read_cr2();
	unsigned long directory_table_offset = ((virt_addr_t *)&vaddr)->pd_offset;
	unsigned long page_table_offset = ((virt_addr_t *)&vaddr)->pt_offset;
	int pid = getpid();
	int new_page_table_frame_number;
	int i;

	int bs_id;
	int pageth;

	pd_t *page_directory_entry = proctab[pid].pdbr + directory_table_offset * sizeof(pd_t);

	// Handle if the address is within range else kill proc
	int vpno = vaddr >> 12, found = 0;

	for (i = 0; i < 8; i++)
	{
		if (bs_pid[i][pid].bs_pid == 1 && bsm_tab[i].bs_status == BSM_MAPPED)
		{
			if (vpno >= bs_pid[i][pid].bs_vpno && vpno < (bs_pid[i][pid].bs_vpno + bsm_tab[i].bs_npages))
			{
				found = 1;
				break;
			}
		}
	}

	// Check if address is in virtual heap
	if (!found)
	{
		struct pentry pptr = proctab[getpid()];
		if (pptr.vhpno != 0)
		{
			if (vpno >= pptr.vhpno && vpno < (pptr.vhpno + pptr.vhpnpages))
			{
				found = 1;
			}
		}
		kprintf("vpno: %08x, vhpno: %08x, vhpnpages: %08x\n", vpno, pptr.vhpno, pptr.vhpnpages);
	}

	// if valid mapping is not found then kill the process
	if (!found)
	{
		kprintf("pfint.c: vaddr not in range\n"); // For debugging
		kill(getpid());
		restore(ps);
		return SYSERR;
	}

	// create page directory if not present
	if (!page_directory_entry->pd_pres)
	{
		// make a page table
		get_frm(&new_page_table_frame_number);
		frm_tab[new_page_table_frame_number].fr_status = FRM_MAPPED;
		frm_tab[new_page_table_frame_number].fr_pid = pid;
		frm_tab[new_page_table_frame_number].fr_type = FR_TBL;

		// make page table for the directory and initialize it
		for (i = 0; i < PAGE_ENTRIES; i++)
		{
			pt_t *page_table_entry = (FRAME0 + new_page_table_frame_number) * NBPG + i * sizeof(pt_t);
			page_table_entry->pt_pres = 0;
			page_table_entry->pt_write = 0;
		}

		page_directory_entry->pd_pres = 1;
		page_directory_entry->pd_write = 1;
		page_directory_entry->pd_base = (FRAME0 + new_page_table_frame_number);
	}

	pt_t *page_table_entry = (pt_t *)((page_directory_entry->pd_base) * NBPG + page_table_offset * sizeof(pt_t));

	// if page is not present in the page table
	if (!page_table_entry->pt_pres)
	{
		get_frm(&new_page_table_frame_number);
		// Insert the frame into the queue
		insert_frame(new_page_table_frame_number);

		/* updating the status of newly created frame */
		frm_tab[new_page_table_frame_number].fr_pid = pid;
		frm_tab[new_page_table_frame_number].fr_status = FRM_MAPPED;
		frm_tab[new_page_table_frame_number].fr_type = FR_PAGE;
		frm_tab[new_page_table_frame_number].fr_vpno = vaddr / NBPG;
		frm_tab[page_directory_entry->pd_base - FRAME0].fr_refcnt++;

		page_table_entry->pt_pres = 1;
		page_table_entry->pt_write = 1;
		page_table_entry->pt_base = FRAME0 + new_page_table_frame_number;

		// bsm lookup and read the data back into the frame
		bsm_lookup(currpid, vaddr, &bs_id, &pageth);
		read_bs((char *)((FRAME0 + new_page_table_frame_number) * NBPG), bs_id, pageth);
	}

	// write the pdbr to cr3 and let it handle the translations
	write_cr3(proctab[pid].pdbr);

	restore(ps);
	return OK;
}
