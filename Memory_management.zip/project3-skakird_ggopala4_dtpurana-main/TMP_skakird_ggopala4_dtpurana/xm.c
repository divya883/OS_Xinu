/* xm.c = xmmap xmunmap */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

/*-------------------------------------------------------------------------
 * xmmap - xmmap
 *-------------------------------------------------------------------------
 */
SYSCALL xmmap(int virtpage, bsd_t source, int npages)
{
  int pid = currpid; // currently executing process

  if (npages <= 0 || npages > 256 || source < 0 || source > 7)
  {
    kprintf("Invalid backing store ID or number of pages\n"); // for debugging, remove later
    return SYSERR;
  }

  // checking if the backing store is already mapped
  //  if(bsm_tab[source].bs_status == BSM_MAPPED){
  //    kprintf("Backing store %d is already mapped\n", source); //for debugging, remove later
  //  }

  if (bsm_map(pid, virtpage, source, npages) == SYSERR)
  {
    kprintf("bsm_map failed\n"); // for debugging, remove later
    return SYSERR;
  }
  return OK;
}
/*-------------------------------------------------------------------------
 * xmunmap - xmunmap
 *-------------------------------------------------------------------------
 */
SYSCALL xmunmap(int virtpage)
{
  int pid = currpid; // currently executing process
  int store;         // backing store entry associated with mapping
  int pageth;        // specifies page offset within that backing store

  if (virtpage < 0)
  {
    return SYSERR;
  }

  if (bsm_lookup(pid, virtpage * NBPG, &store, &pageth) == SYSERR)
  {
    kprintf("bsm_lookup failed for page $d\n", virtpage); // for debugging, remove later
    return SYSERR;
  }

  // remove mapping from bsm_tab
  if (bsm_unmap(pid, virtpage, 0) == SYSERR)
  {
    kprintf("bsm_unmap failed\n"); // for debugging, remove later
    return SYSERR;
  }

  return OK;
}
