/* frame.c - manage physical frames */
#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

/*-------------------------------------------------------------------------
 * init_frm - initialize frm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL init_frm()
{
    STATWORD ps;
    disable(ps);

    int idx = 0;
    while (idx < NFRAMES)
    {
        fr_map_t *frame = &frm_tab[idx];
        frame->fr_status = FRM_UNMAPPED;
        frame->fr_pid = -1;
        frame->fr_vpno = 0;
        frame->fr_refcnt = 0;
        frame->fr_type = FR_PAGE;
        frame->fr_dirty = 0;
        idx++;
    }

    restore(ps);
    return OK;
}

/*-------------------------------------------------------------------------
 * get_frm - get a free frame according page replacement policy
 *-------------------------------------------------------------------------
 */
SYSCALL get_frm(int *avail)
{
    STATWORD ps;
    disable(ps);

    int i;

    // get available unmapped frame (if we can)
    int new_frame = check_new_frame(avail);
    if (new_frame == OK)
    {
        // kprintf("avail is: %d\n", *avail);
        restore(ps);
        return OK;
    }

    // get frame to kick from replacement policy
    // FYI this made our life hell
    if (page_replace_policy == SC)
        new_frame = apply_SC();
    // kprintf("avail is lalala: %d\n", new_frame);

    if (sc_debug == 1)
        kprintf("\n Frame to be removed  %d\n", new_frame);

    // If new frame is found, then free the existing values and return the frame#
    if (new_frame > -1)
    {
        free_frm(new_frame);
        *avail = new_frame;
        restore(ps);
        return OK;
    }

    // Else error
    restore(ps);
    return SYSERR;
}
/*-------------------------------------------------------------------------
 * free_frm - free a frame
 *-------------------------------------------------------------------------
 */
SYSCALL free_frm(int i)
{

    STATWORD ps;
    disable(ps);

    pd_t *pd_entry;
    pt_t *pt_entry;
    virt_addr_t *virt_addr;

    if (i >= NFRAMES || frm_tab[i].fr_type != FR_PAGE)
    {
        restore(ps);
        return SYSERR;
    }

    unsigned long vaddr, pdbr;
    int bs_id;
    int pageth;
    unsigned int vpd_offset, vpt_offset;
    fr_map_t current_frm = frm_tab[i];

    if (i >= 0 && i < NFRAMES)
    {
        if (current_frm.fr_type == FR_PAGE)
        {
            bs_id = proctab[current_frm.fr_pid].store;
            pdbr = proctab[current_frm.fr_pid].pdbr;
            pageth = current_frm.fr_vpno - proctab[current_frm.fr_pid].vhpno;
            // bsm_lookup(currpid, vaddr, &bs_id, &pageth);

            vaddr = current_frm.fr_vpno * NBPG; /* Make full 32 bit by left shifting 12 bits (4096) */

            // get addresses from the virtual address
            virt_addr = (virt_addr_t *)&vaddr;
            vpd_offset = virt_addr->pd_offset;
            vpt_offset = virt_addr->pt_offset;

            // kprintf("\n pd offset %d, pt offset %d",vpd_offset,vpt_offset);

            pd_entry = pdbr + vpd_offset * sizeof(pd_t);
            pt_entry = (pt_t *)(pd_entry->pd_base * NBPG + vpt_offset * sizeof(pt_t));

            // if (i == 8)
            // {
            //     kprintf("frame.c free_frm: %d, vpage: %d\n", bs_id, pageth);
            // }
            // write to backing store
            write_bs((i + FRAME0) * NBPG, bs_id, pageth);
            // set dirty bit becasue written to backing store
            frm_tab[pd_entry->pd_base - FRAME0].fr_dirty = 1;

            // decrease ref count because being written to the backing store
            frm_tab[pd_entry->pd_base - FRAME0]
                .fr_refcnt--;

            pd_t *page_directory_entry = proctab[currpid].pdbr + vpd_offset * sizeof(pd_t);
            pt_t *page_table_entry = (pt_t *)((page_directory_entry->pd_base) * NBPG + vpt_offset * sizeof(pt_t));
            // reset the present bit because written to the backing store
            page_table_entry->pt_pres = 0;

            if (frm_tab[pd_entry->pd_base - FRAME0].fr_refcnt == 0)
            {
                unmap_frm(pd_entry);
            }

            restore(ps);
            return (OK);
        }
    }
}

void unmap_frm(pd_t *pd_entry)
{
    frm_tab[pd_entry->pd_base - FRAME0].fr_status = FRM_UNMAPPED;
    frm_tab[pd_entry->pd_base - FRAME0].fr_type = FR_PAGE;
    frm_tab[pd_entry->pd_base - FRAME0].fr_pid = -1;
    frm_tab[pd_entry->pd_base - FRAME0].fr_vpno = 4096;
}

int check_new_frame(int *avail_frame)
{
    int i;
    for (i = 0; i < NFRAMES; i++)
    {
        if (frm_tab[i].fr_status == FRM_UNMAPPED)
        {
            *avail_frame = i; // Found an unmapped frame
            // kprintf("Frame %d is unmapped and available.\n", i); // Debugging message
            return OK;
        }
    }
    return 0;
}

int apply_SC()
{

    pd_t *pagedir_entry;
    pt_t *pagetable_entry;
    virt_addr_t *virt_addr;

    unsigned long pdbr, vaddr, vpd_offset, vpt_offset;
    int cur = sc_head, prev = -1;
    // kprintf("initial head is: %d\n", sc_head);

    while (cur != -1)
    {
        if (frm_tab[cur].fr_type != FR_PAGE)
        {
            prev = cur;
            cur = sc_queue[cur].next;
            continue;
        }
        // To check if the frame has been accessed, we need to use pt_acc by calculating the exact entry
        pdbr = proctab[currpid].pdbr;
        vaddr = frm_tab[cur].fr_vpno * NBPG;
        virt_addr = (virt_addr_t *)&vaddr;
        vpd_offset = virt_addr->pd_offset;
        vpt_offset = virt_addr->pt_offset;
        pagedir_entry = pdbr + vpd_offset * sizeof(pd_t);
        pagetable_entry = (pt_t *)(pagedir_entry->pd_base * NBPG + vpt_offset * sizeof(pt_t));

        // Now check if the entry is accessed
        if (pagetable_entry->pt_acc == 1)
        {
            pagetable_entry->pt_acc = 0;
        }
        // We need to map prev's next to cur's next since cur is no longer going to be present
        else if (pagetable_entry->pt_acc == 0)
        {

            // IF head is the unused element, move head ELSE link prev.next to cur.next
            if (prev == -1)
                sc_head = sc_queue[cur].next;
            else
                sc_queue[prev].next = sc_queue[cur].next;

            // Element effectively removed
            sc_queue[cur].next = -1;

            return cur;
        }
        prev = cur;
        cur = sc_queue[cur].next;
    }

    // sc_head has no unreferenced frames, rotate it and remove
    cur = sc_head;
    sc_head = sc_queue[cur].next;
    sc_queue[cur].next = -1;

    return cur;
}

void insert_frame(int frame)
{

    STATWORD ps;
    disable(ps);
    // kprintf("inserting %d frame \n", frame);

    // If it is first, insert and return OK
    if (sc_head == -1)
    {
        sc_head = frame;
        restore(ps);
        return OK;
    }

    // If it is not, then insert at the end
    int cur, next;
    cur = sc_head;
    while (sc_queue[cur].next != -1)
    {
        cur = sc_queue[cur].next;
    }
    sc_queue[cur].next = frame;
    sc_queue[frame].next = -1;
}