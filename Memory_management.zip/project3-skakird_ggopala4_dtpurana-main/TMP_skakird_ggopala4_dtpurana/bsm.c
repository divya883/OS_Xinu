/* bsm.c - manage the backing store mapping*/

#include <conf.h>
#include <kernel.h>
#include <paging.h>
#include <proc.h>

/*-------------------------------------------------------------------------
 * init_bsm- initialize bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL init_bsm()
{
    int i = 0;
    int ppid;
    while (i < 8)
    {
        bsm_tab[i].bs_status = BSM_UNMAPPED;
        for (ppid = 0; ppid < NPROC; ppid++)
        {
            bs_pid[i][ppid].bs_pid = -1;
            bs_pid[i][ppid].bs_vpno = 4096;
        }
        bsm_tab[i].bs_npages = 0;
        bsm_tab[i].bs_sem = 0;
        i++;
    }

    return OK;
}

/*-------------------------------------------------------------------------
 * get_bsm - get a free entry from bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL get_bsm(int *avail)
{
    int i = 0;
    while (i < 8)
    {
        if (bsm_tab[i].bs_status == BSM_UNMAPPED)
        {
            *avail = i;
            return OK;
        }
        i++;
    }
    return SYSERR;
}

/*-------------------------------------------------------------------------
 * free_bsm - free an entry from bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL free_bsm(int i)
{
    release_bs(i);
}

/*-------------------------------------------------------------------------
 * bsm_lookup - lookup bsm_tab and find the corresponding entry
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_lookup(int pid, long vaddr, int *store, int *pageth)
{
    int i;
    int vpno = vaddr >> 12;
    for (i = 0; i < 8; i++)
    {

        if (bs_pid[i][pid].bs_pid == 1)
        {

            // if (vpno >= bsm_tab[i].bs_vpno && vpno < (bsm_tab[i].bs_vpno + bsm_tab[i].bs_npages))
            // {

            *store = i;
            *pageth = vpno - bs_pid[i][pid].bs_vpno;
            return OK;
            // }
            // else
            // {
            //     kprintf("Error: virtual page number out of range\n"); // For debugging, remove later
            //     return SYSERR;
            // }
        }
        // else
        // {
        //     kprintf("Error: PID mismatch\n"); // For debugging, remove later
        //     return SYSERR;
        // }
    }
    kprintf("Error: PID mismatch\n"); // For debugging, remove later
    return SYSERR;
    return 0;
}

/*-------------------------------------------------------------------------
 * bsm_map - add an mapping into bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_map(int pid, int vpno, int source, int npages)
{
    // bs_pid_map bs_data = bs_pid[source][pid];
    if (npages + bsm_tab[source].bs_npages > 4096)
    {
        kprintf("Error: Not enough space in the backing store\n"); // For debugging, remove later
        return SYSERR;
    }
    bsm_tab[source].bs_npages += npages;
    bs_pid[source][pid].bs_pid = 1;
    bs_pid[source][pid].bs_vpno = vpno;
    bsm_tab[source].bs_status = BSM_MAPPED;

    proctab[currpid].vhpno = vpno;
    proctab[currpid].store = source;
    return OK;
}

/*-------------------------------------------------------------------------
 * bsm_unmap - delete an mapping from bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_unmap(int pid, int vpno, int flag)
{
    // Not sure why a flag is needed, need to figure out. Also, check vpno condition
    int i;
    for (i = 0; i < 8; i++)
    {
        // bs_pid_map bs_data = bs_pid[i][pid];

        if (bs_pid[i][pid].bs_pid == 1 && bs_pid[i][pid].bs_vpno <= vpno)
        {

            if (bsm_tab[i].bs_status = BSM_MAPPED)
            {

                bsm_tab[i].bs_npages = 0;
                bs_pid[i][pid].bs_pid = -1;
                bsm_tab[i].bs_status = BSM_UNMAPPED;
                bs_pid[i][pid].bs_vpno = 4096;
                bsm_tab[i].bs_sem = 0;
                return 0; // Success case, no need to check for the rest of the mapping
            }
            else
            {
                kprintf("pid matches but status not updated in bs_map"); // Debugging, remove later
                return SYSERR;
            }
        }
        else
            continue;
    }
}
