/* vcreate.c - vcreate */

#include <conf.h>
#include <i386.h>
#include <kernel.h>
#include <proc.h>
#include <sem.h>
#include <mem.h>
#include <io.h>
#include <paging.h>

/*
static unsigned long esp;
*/

LOCAL newpid();
/*------------------------------------------------------------------------
 *  create  -  create a process to start running a procedure
 *------------------------------------------------------------------------
 */
SYSCALL vcreate(procaddr, ssize, hsize, priority, name, nargs, args)
int *procaddr; /* procedure address		*/
int ssize;	   /* stack size in words		*/
int hsize;	   /* virtual heap size in pages	*/
int priority;  /* process priority > 0		*/
char *name;	   /* name (for debugging)		*/
int nargs;	   /* number of args that follow	*/
long args;	   /* arguments (treated like an	*/
			   /* array in the code)		*/
{
	if (hsize < 1 || hsize > 256)
	{
		kprintf("Error: Invalid heap size\n");
		return SYSERR;
	}
	int i;
	int bsm_id;
	int new_pid;
	struct mblock *store_address;
	if (get_bsm(&bsm_id) == SYSERR)
	{
		kprintf("No free bsm available\n");
		return SYSERR;
	}
	bsm_tab[bsm_id].has_private_heap = 1;
	new_pid = create(procaddr, ssize, priority, name, nargs, args);
	bsm_map(new_pid, 4096, bsm_id, hsize);

	store_address = BACKING_STORE_BASE + (bsm_id * BACKING_STORE_UNIT_SIZE);
	store_address->mnext = NULL;
	store_address->mlen = hsize * NBPG;

	proctab[new_pid].store = bsm_id;
	proctab[new_pid].vhpno = 4096;
	proctab[new_pid].vhpnpages = hsize;
	proctab[new_pid].vmemlist->mnext = 4096 * NBPG;
	return new_pid;
}

/*------------------------------------------------------------------------
 * newpid  --  obtain a new (free) process id
 *------------------------------------------------------------------------
 */
LOCAL newpid()
{
	int pid; /* process id to return		*/
	int i;

	for (i = 0; i < NPROC; i++)
	{ /* check all NPROC slots	*/
		if ((pid = nextproc--) <= 0)
			nextproc = NPROC - 1;
		if (proctab[pid].pstate == PRFREE)
			return (pid);
	}
	return (SYSERR);
}
