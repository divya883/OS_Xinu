#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

int get_bs(bsd_t bs_id, unsigned int npages)
{

  /* requests a new mapping of npages with ID map_id */
  // kprintf("To be implemented!\n");

  if (bs_id > 7 || npages > 256)
  {
    return SYSERR;
  }

  if (bsm_tab[bs_id].bs_status == BSM_MAPPED)
  {
    if ((bs_pid[bs_id][currpid].bs_pid != 1) && (bsm_tab[bs_id].has_private_heap == 1))
    {
      return SYSERR;
    }

    if ((bsm_tab[bs_id].bs_npages + npages) <= 256)
    {

      return npages;
    }
    else
    {

      return SYSERR;
    }
  }
  else if (bsm_tab[bs_id].bs_status == BSM_UNMAPPED)
  {

    return npages;
  }

  return SYSERR;
}
