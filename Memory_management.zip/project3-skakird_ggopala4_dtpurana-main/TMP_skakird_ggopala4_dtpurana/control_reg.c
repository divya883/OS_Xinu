/* control_reg.c - read_cr0 read_cr2 read_cr3 read_cr4
       write_cr0 write_cr3 write_cr4 enable_pagine */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

unsigned long tmp;

/*-------------------------------------------------------------------------
 * read_cr0 - read CR0
 *-------------------------------------------------------------------------
 */
unsigned long read_cr0(void)
{

  STATWORD ps;
  unsigned long local_tmp;

  disable(ps);

  asm("pushl %eax");
  asm("movl %cr0, %eax");
  asm("movl %eax, tmp");
  asm("popl %eax");

  local_tmp = tmp;

  restore(ps);

  return local_tmp;
}

/*-------------------------------------------------------------------------
 * read_cr2 - read CR2
 *-------------------------------------------------------------------------
 */

unsigned long read_cr2(void)
{

  STATWORD ps;
  unsigned long local_tmp;

  disable(ps);

  asm("pushl %eax");
  asm("movl %cr2, %eax");
  asm("movl %eax, tmp");
  asm("popl %eax");

  local_tmp = tmp;

  restore(ps);

  return local_tmp;
}

/*-------------------------------------------------------------------------
 * read_cr3 - read CR3
 *-------------------------------------------------------------------------
 */

unsigned long read_cr3(void)
{

  STATWORD ps;
  unsigned long local_tmp;

  disable(ps);

  asm("pushl %eax");
  asm("movl %cr3, %eax");
  asm("movl %eax, tmp");
  asm("popl %eax");

  local_tmp = tmp;

  restore(ps);

  return local_tmp;
}

/*-------------------------------------------------------------------------
 * read_cr4 - read CR4
 *-------------------------------------------------------------------------
 */

unsigned long read_cr4(void)
{

  STATWORD ps;
  unsigned long local_tmp;

  disable(ps);

  asm("pushl %eax");
  asm("movl %cr4, %eax");
  asm("movl %eax, tmp");
  asm("popl %eax");

  local_tmp = tmp;

  restore(ps);

  return local_tmp;
}

/*-------------------------------------------------------------------------
 * write_cr0 - write CR0
 *-------------------------------------------------------------------------
 */

void write_cr0(unsigned long n)
{

  STATWORD ps;

  disable(ps);

  tmp = n;
  asm("pushl %eax");
  asm("movl tmp, %eax"); /* mov (move) value at tmp into %eax register.
          "l" signifies long (see docs on gas assembler)	*/
  asm("movl %eax, %cr0");
  asm("popl %eax");

  restore(ps);
}

/*-------------------------------------------------------------------------
 * write_cr3 - write CR3
 *-------------------------------------------------------------------------
 */

void write_cr3(unsigned long n)
{

  STATWORD ps;

  disable(ps);

  tmp = n;
  asm("pushl %eax");
  asm("movl tmp, %eax"); /* mov (move) value at tmp into %eax register.
                            "l" signifies long (see docs on gas assembler)       */
  asm("movl %eax, %cr3");
  asm("popl %eax");

  restore(ps);
}

/*-------------------------------------------------------------------------
 * write_cr4 - write CR4
 *-------------------------------------------------------------------------
 */

void write_cr4(unsigned long n)
{

  STATWORD ps;

  disable(ps);

  tmp = n;
  asm("pushl %eax");
  asm("movl tmp, %eax"); /* mov (move) value at tmp into %eax register.
                            "l" signifies long (see docs on gas assembler)       */
  asm("movl %eax, %cr4");
  asm("popl %eax");

  restore(ps);
}

/*-------------------------------------------------------------------------
 * enable_pagine - enable paging
 *-------------------------------------------------------------------------
 */
void enable_paging()
{

  unsigned long temp = read_cr0();
  temp = temp | (0x1 << 31) | 0x1;
  write_cr0(temp);
}

void intialize_paging()
{
  int i;
  int j;
  pt_t *page_table_entry;
  pd_t *page_directory_entry;
  int fr_id = 0;

  init_bsm(); /* initializing the bsm map table */
  init_frm(); /* initializing the frame map table */

  /* Initialize the circular queue for SC algorithm */
  sc_head = -1; /* head of the circular queue */
  sc_tail = -1; /* Tail of the circular queue */
  sc_count = 0; /* Number of frames in the queue */
  for (i = 0; i < NFRAMES; i++)
  {
    sc_queue[i].next = -1; /* initializing all entries as empty */
  }

  /* creating global page tables that will map pages 0 to 4095 to real XINU physical memory 16MB */

  for (i = 0; i < 4; i++)
  {
    get_frm(&fr_id);
    frm_tab[fr_id].fr_status = FRM_MAPPED;
    frm_tab[fr_id].fr_type = FR_TBL;
    frm_tab[fr_id].fr_pid = NULLPROC;

    page_table_entry = (FRAME0 + fr_id) * NBPG;

    for (j = 0; j < PAGE_ENTRIES; j++)
    {
      page_table_entry->pt_pres = 1;
      page_table_entry->pt_write = 1;
      page_table_entry->pt_user = 0;
      page_table_entry->pt_pwt = 0;
      page_table_entry->pt_pcd = 0;
      page_table_entry->pt_acc = 0;
      page_table_entry->pt_dirty = 0;
      page_table_entry->pt_mbz = 0;
      page_table_entry->pt_global = 1;
      page_table_entry->pt_avail = 0;
      page_table_entry->pt_base = i * FRAME0 + j;
      page_table_entry++;
    }
  }

  /* allocating first 4 global page directory entries  */
  get_frm(&fr_id);
  proctab[NULLPROC].pdbr = (fr_id + FRAME0) * NBPG;
  frm_tab[fr_id].fr_status = FRM_MAPPED;
  frm_tab[fr_id].fr_type = FR_DIR;
  frm_tab[fr_id].fr_pid = NULLPROC;

  page_directory_entry = proctab[NULLPROC].pdbr;

  for (i = 0; i < PAGE_ENTRIES; i++)
  {
    page_directory_entry[i].pd_write = 1;

    if (i < 4)
    {
      page_directory_entry[i].pd_pres = 1;
      page_directory_entry[i].pd_base = FRAME0 + i;
    }
  }
}