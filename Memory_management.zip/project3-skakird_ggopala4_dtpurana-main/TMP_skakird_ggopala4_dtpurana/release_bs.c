#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

SYSCALL release_bs(bsd_t bs_id)
{

  /* release the backing store with ID bs_id */
  // kprintf("To be implemented!\n");
  int i;
  if (bs_id > 7)

    return SYSERR;

  if (bsm_tab[bs_id].bs_status == BSM_MAPPED)
  {

    bsm_tab[bs_id].bs_status = BSM_UNMAPPED;

    bsm_tab[bs_id].bs_npages = 0;

    for (i = 0; i < NPROC; i++)
    {
      bs_pid[bs_id][i].bs_pid = -1;
      bs_pid[bs_id][i].bs_vpno = 4096;
    }

    bsm_tab[bs_id].bs_sem = 0;

    return OK;
  }

  return SYSERR;
}
