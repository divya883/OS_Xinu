#define EXPDISTSCHED 1
#define LINUXSCHED 2

extern int currently_sched;
void setschedclass(int sched_class);
int getschedclass();
void next_epoch();
