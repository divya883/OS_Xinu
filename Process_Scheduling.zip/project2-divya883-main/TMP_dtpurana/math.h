#ifndef _MATH_H_
#define _MATH_H_

double pow(double x, int y);
double taylor_log(double input);
double log(double x);
double expdev(double lamda);

#endif