/* resched.c  -  resched */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include <math.h>
#include <sched.h>

unsigned long currSP;	/* REAL sp of current process */
extern int ctxsw(int, int, int, int);
/*-----------------------------------------------------------------------
 * resched  --  reschedule processor to highest priority ready process
 *
 * Notes:	Upon entry, currpid gives current process id.
 *		Proctab[currpid].pstate gives correct NEXT state for
 *			current process if other than PRREADY.
 *------------------------------------------------------------------------
 */
int resched()
{
	register struct	pentry	*optr;	/* pointer to old process entry */
	register struct	pentry	*nptr;	/* pointer to new process entry */

	int next_pid = q[rdyhead].qnext; /* stores next pid from ready queue */
	int exp_rand_value; /* randomly generated value for the exponential scheduler */
	int process = 0; /* track highest priority process in Linux-like scheduler */
	int max_goodness = 0; /* stores max goodness value for Linux-like scheduler */


	if (getschedclass() == EXPDISTSCHED) {
		exp_rand_value = (int)expdev(0.1); /* Generate an exponentially distributed random value */
		optr = &proctab[currpid];

		/* Skip the null process if it is the only one and there are other processes in the queue */
		if (next_pid == NULLPROC && q[rdyhead].qnext != q[rdytail].qprev) {
			next_pid = q[next_pid].qnext;
		} else if (next_pid == NULLPROC) {
			/* Handle the case where the current process is still running */
			if (optr->pstate == PRCURR) {
				#ifdef RTCLOCK
					preempt = QUANTUM; /* Reset the time quantum */
				#endif
				return(OK); /* Context switch is not needed */ 
		} else {
			/* Dequeue and switch to the null process */
			nptr = &proctab[(currpid = dequeue(NULLPROC))];
			nptr->pstate = PRCURR; /* marking null process as current */
			#ifdef RTCLOCK
				preempt = QUANTUM;
			#endif
			ctxsw((int) &optr->pesp, (int) optr->pirmask, (int) &nptr->pesp, (int) nptr->pirmask);
			return OK;
		}
	}

	/* check whether there is a valid process in the ready queue */
	if (q[rdytail].qprev < NPROC) {
		/* Traverse ready queue until a process with a priority greater than exp_rand_value */
		while (q[next_pid].qkey < exp_rand_value && q[next_pid].qnext < NPROC) 
		{
			next_pid = q[next_pid].qnext;
		}
		/* check whether the current process should continue running */
		if (optr->pstate == PRCURR && 
		((optr->pprio > exp_rand_value &&
		(q[next_pid].qkey > optr->pprio || q[next_pid].qkey <= exp_rand_value)) ||
		(optr->pprio < exp_rand_value && q[next_pid].qkey < optr->pprio))) {
			#ifdef RTCLOCK
				preempt = QUANTUM;
			#endif
			return(OK); /* No context switch needed */
		}
		/* If rescheduling is required, mark the current process as ready */
		if(optr->pstate == PRCURR) {
			optr->pstate = PRREADY;
			insert(currpid, rdyhead, optr->pprio); /* Insert current process back into ready queue */
		}
		
		/* Dequeue and switch to the process with priority > exp_rand_value */
		nptr = &proctab[(currpid = dequeue(next_pid))];
		nptr->pstate = PRCURR; /* Mark the selected process as running */
		#ifdef RTCLOCK
			preempt = QUANTUM; /* reset time quantam */
		#endif
		ctxsw((int) &optr->pesp, (int) optr->pirmask, (int) &nptr->pesp, (int) nptr->pirmask);
		return OK;
	} else {
		#ifdef RTCLOCK
			preempt = QUANTUM; /* Reset time quantum */
		#endif
		return(OK); /* No context switch needed */
	}
	}
	else if (getschedclass() == LINUXSCHED) {
		optr = &proctab[currpid]; /* Get the current process's entry */
		optr->goodness_value += preempt - optr->counter; /* update process priority dynamically */
		optr->counter = preempt; /* set remaining time quantum */

		/* Handle case where process has used up its quantum or is the null process */
		if (preempt <= 0 || currpid == NULLPROC) {
			optr->counter = 0; /* reset counter */
			optr->goodness_value = 0; /* reset goodness value */
		}

		/* Traverse the ready queue to find process with highest goodness value */
		while (next_pid != rdytail && next_pid < NPROC) {
			if (proctab[next_pid].goodness_value > max_goodness) {
				process = next_pid; /* track the process with the highest goodness */
				max_goodness = proctab[next_pid].goodness_value;
			}
			next_pid = q[next_pid].qnext;
		}

		/* If no process has goodness > 0, start a new epoch */
		if ((optr->pstate != PRCURR || optr->counter == 0) && max_goodness == 0) {
			next_epoch(); /* Start a new scheduling epoch */
			preempt = optr->counter; /* reset time quantum */

			/* If there is still no runnable process */
			if (max_goodness == 0){
				if (currpid == NULLPROC) {
					return OK; /* No need to switch, continue with null process */
				} else {
					if (optr->pstate == PRCURR) {
						optr->pstate = PRREADY; /* Mark current process as ready */
						insert(currpid, rdyhead, optr->pprio); /* reinsert current process into queue */
					}

					/* Switch to the null process */
					nptr = &proctab[(currpid = dequeue(NULLPROC))];
					nptr->pstate = PRCURR; /* Mark null process as running */
					#ifdef RTCLOCK
						preempt = QUANTUM;
					#endif
					ctxsw((int)&optr->pesp, (int)optr->pirmask, (int)&nptr->pesp, (int)nptr->pirmask);
					return OK;
				}
			}
		}
		/* Continue with the current process if it has the highest goodness */
		if(optr->pstate == PRCURR && optr->goodness_value > 0 && optr->goodness_value >max_goodness) {
			preempt = optr->counter;
			return(OK);
		}

		/* check whether the process with the highest goodness should run */
		if((optr->counter == 0 || optr->pstate != PRCURR || optr->goodness_value < max_goodness) && max_goodness > 0) {
			if(optr->pstate == PRCURR) {
				optr->pstate = PRREADY; /* Mark the current process as ready */
				insert(currpid, rdyhead, optr->pprio); /* reinsert into ready queue */
			}
			
			/* Dequeue and switch to the process with the highest goodness */
			nptr = &proctab[(currpid = dequeue(process))];
			nptr->pstate = PRCURR; /* Mark the selected process as running */
			preempt = nptr->counter; /* Setting the time quantum */
			ctxsw((int) &optr->pesp, (int)optr->pirmask, (int) &nptr->pesp, (int)nptr->pirmask);
			return OK;
		}
		return OK;
	}
	else //default
	{
		/* no switch needed if current process priority higher than next*/

		if ( ( (optr= &proctab[currpid])->pstate == PRCURR) &&
	   		(lastkey(rdytail)<optr->pprio)) {
			return(OK);
		}
	
		/* force context switch */

		if (optr->pstate == PRCURR) {
			optr->pstate = PRREADY;
			insert(currpid,rdyhead,optr->pprio);
		}

		/* remove highest priority process at end of ready list */

		nptr = &proctab[ (currpid = getlast(rdytail)) ];
		nptr->pstate = PRCURR;		/* mark it currently running	*/
		#ifdef	RTCLOCK
				preempt = QUANTUM;		/* reset preemption counter	*/
		#endif
	
		ctxsw((int)&optr->pesp, (int)optr->pirmask, (int)&nptr->pesp, (int)nptr->pirmask);
	
		/* The OLD process returns here when resumed. */
		return OK;
	}
}
