#include <conf.h>
#include <kernel.h>
#include <sched.h>
#include <sched.h>
#include <proc.h>

/* Global variable to store the current scheduling class */
int currently_sched; 

/* Function to set the current scheduling class */
void setschedclass(int sched_class) {
    currently_sched = sched_class;
}

/* Function to retrieve the current scheduling class */
int getschedclass() {
    return currently_sched;
}

/* Function to initialize a new epoch for the Linux-based scheduler */
void next_epoch() {
    struct pentry *proc;  /* Pointer to a process entry */
    int i;

    /* Loop through all processes to set their quantum and goodness */
    for (i = 0; i < NPROC; i++) {
        proc = &proctab[i];

        /* Only update processes that are not free */
        if (proc->pstate != PRFREE) {
            /* If the process has no remaining quantum or did not run in the last epoch */
            if (proc->counter == 0 || proc->counter == proc->quantum_time) {
                proc->quantum_time = proc->pprio;  /* Set time quantum equal to priority */
            } else {
                /* Set the quantum as priority plus half of the remaining quantum */
                proc->quantum_time = proc->pprio + (proc->counter / 2);
            }

            /* Set the process's counter and goodness */
            proc->counter = proc->quantum_time;
            proc->goodness_value = proc->pprio + proc->counter;
        }
    }
}
