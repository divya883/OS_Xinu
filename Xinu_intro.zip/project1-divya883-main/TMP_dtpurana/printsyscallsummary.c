#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include "lab0.h"
#include <stdio.h>

/* Declare and initialize global variables */
struct processStats procStatsTable[];
int isTracingEnabled;  /* Flag to track if syscall tracing is enabled */

/* Array to map syscall IDs to their names */
const char* syscallNames[27] = {
    "freemem", "chprio", "getpid", "getprio", "gettime", 
    "kill", "receive", "recvclr", "recvtim", "resume", 
    "scount", "sdelete", "send", "setdev", "setnok", 
    "screate", "signal", "signaln", "sleep", "sleep10", 
    "sleep100", "sleep1000", "sreset", "stacktrace", 
    "suspend", "unsleep", "wait"
};

/* Prints the summary of system calls for all processes */
void printsyscallsummary() {
    kprintf("\n\nvoid printsyscallsummary()");
    int processId, syscallId;
    for (processId = 1; processId <= NPROC; processId++) {
        if (procStatsTable[processId].hasSyscallInvoked) {
            kprintf("\nProcess [pid: %d]", processId);

            for (syscallId = 0; syscallId < 27; syscallId++) {
                if (procStatsTable[processId].syscallFreq[syscallId] > 0) {
                    int averageTime = (int)(procStatsTable[processId].totalExecTime[syscallId] / procStatsTable[processId].syscallFreq[syscallId]);
                    kprintf("\nSyscall: sys_%s, count: %d, average execution time: %d (ms)", syscallNames[syscallId], procStatsTable[processId].syscallFreq[syscallId], averageTime);
                }
            }
        }
    }
}

/* Initializes the accounting data and starts tracing */
void syscallsummary_start() {

    int processId, syscallId;
    /* Reset syscall accounting data for all processes */
    for (processId = 1; processId <= NPROC; processId++) {
        procStatsTable[processId].hasSyscallInvoked = 0;

        for (syscallId = 0; syscallId < 27; syscallId++) {
            procStatsTable[processId].syscallFreq[syscallId] = 0;
            procStatsTable[processId].totalExecTime[syscallId] = 0;
        }
    }

    isTracingEnabled = 1;   /* Enable syscall tracing */
}

/* Stops tracing system calls */
void syscallsummary_stop() {
    isTracingEnabled = 0;   /* Disable syscall tracing */
}

/* Updates syscall accounting data when a system call is invoked */
void updateSyscallAccounting(int syscallId, unsigned long execTime) {
    if (currpid > 0 && currpid <= NPROC) {
        procStatsTable[currpid].syscallFreq[syscallId]++;
        procStatsTable[currpid].totalExecTime[syscallId] += execTime;
        procStatsTable[currpid].hasSyscallInvoked = 1;  /* Mark that the process invoked at least one syscall */
    }
}
