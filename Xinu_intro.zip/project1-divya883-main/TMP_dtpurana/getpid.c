/* getpid.c - getpid */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include "lab0.h"

/*------------------------------------------------------------------------
 * getpid  --  get the process id of currently executing process
 *------------------------------------------------------------------------
 */
int isTracingEnabled;
SYSCALL getpid()
{	
	//unsigned long ctr1000;
	unsigned long timeTaken = ctr1000;
	if(isTracingEnabled) {
			timeTaken = ctr1000 - timeTaken;
			updateSyscallAccounting(2, timeTaken);
	}
	return(currpid);
}
