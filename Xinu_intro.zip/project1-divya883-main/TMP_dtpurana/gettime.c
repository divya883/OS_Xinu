/* gettime.c - gettime */

#include <conf.h>
#include <kernel.h>
#include <date.h>
#include "lab0.h"

extern int getutim(unsigned long *);

/*------------------------------------------------------------------------
 *  gettime  -  get local time in seconds past Jan 1, 1970
 *------------------------------------------------------------------------
 */
int isTracingEnabled;
SYSCALL	gettime(long *timvar)
{
    /* long	now; */

	/* FIXME -- no getutim */
    //unsigned long ctr1000;
    unsigned long timeTaken = ctr1000;

    if(isTracingEnabled) {
			timeTaken = ctr1000 - timeTaken;
			updateSyscallAccounting(4, timeTaken);
	}

    return OK;
}
