#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>

extern long zfunction(long);
extern void printprocstks(int priority);
extern void syscallsummary_start();
extern void syscallsummary_stop();
extern void printsyscallsummary();
int mainpid;
void launch_process(void);
void initiateProcess();

//for testing purposes
int prX,prY,prZ;
void halt();
/*------------------------------------------------------------------------
 *  main  --  user main program
 *------------------------------------------------------------------------
 */
prch(c)
char c;
{
    int i;
    sleep(5);	
}
int main()
{   
    
    kprintf("\n\nHello CSC 501\n\n");
    syscallsummary_start();
	mainpid = getpid();
    kprintf("\nTask 1 (ZFunction)\n");
	kprintf("\nZfunction(0xaabbccdd) : 0x%08x\n", zfunction(0xaabbccdd));
	launch_process();
    kprintf("\nTask 2 (Print Process Stack)\n");
	printprocstks(10);
    /*
    getpid();
	getpid();
    sleep(10);
    sleep100(10);
    sleep1000(5);
	getprio(mainpid);
	getpid();
	getpid();
    kprintf("\nTask 3 (Print System Calls Summary)\n");
    printsyscallsummary();
    syscallsummary_stop();
    */
    kprintf("Task 3 (printsyscallsummary)\n");
    syscallsummary_start();        
    resume(prX = create(prch,2000,20,"proc X",1,'X'));
    sleep(10);
    syscallsummary_stop();
    printsyscallsummary();
	return 0;

}
void initiateProcess() {
    // Introduce a brief delay
    sleep1000(5);

    // Fetch and store the current process ID
    int process_id = getpid();
    
    // Suspend the current process
    suspend(process_id);

    // Set a notification on the main process
    setnok(mainpid, process_id);

    // Terminate the current process
    kill(process_id);
}

void launch_process(void) {
	/*SYSCALL create(procaddr,ssize,priority,name,nargs,args)
 * 	int	*procaddr;		 procedure address		
	int	ssize;			 stack size in words		
	int	priority;		 process priority > 0		
	char	*name;			 name (for debugging)		
	int	nargs;			 number of args that follow	
	long	args;			 arguments (treated like an array in the code)
				
 * */
    int stack_size = 1024;
    int priority = 40;
    char *proc_name = "proc A";
    int args_count = 1;
    long arg_val = 30;

    // Resume the newly created process
    resume(create((int *) &initiateProcess, stack_size, priority, proc_name, args_count, arg_val));
}

