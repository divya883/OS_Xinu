#ifndef _LAB0_H
#define _LAB0_H

extern long zfunction(long param);
extern void printprocstks(int priority);
extern void printsyscallsummary();
extern void syscallsummary_start();
extern void syscallsummary_stop();

extern unsigned long ctr1000;
extern int isTracingEnabled;

struct processStats {
    int hasSyscallInvoked;   /* Indicates if process has invoked any syscall */
    int syscallFreq[27];    /* Stores the number of times each system call is invoked */
    unsigned long totalExecTime[27];   /* Stores the total execution time for each system call */
};

extern struct processStats procStatsTable[];

#endif
