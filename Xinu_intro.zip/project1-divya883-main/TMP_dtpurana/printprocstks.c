#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>

void printprocstks(int priority) {
    int i;
    unsigned long *esp, *ebp;

    // Inline assembly to get the current stack and frame pointer of the running process
    asm("movl %%esp, %0" : "=r"(esp));
    asm("movl %%ebp, %0" : "=r"(ebp));

    for (i = 0; i < NPROC; i++) {
        struct pentry *proc = &proctab[i];

        // Ignore processes that are not active (free slots) or have lower/equal priority
        if (proc->pstate == PRFREE || proc->pprio <= priority) {
            continue;
        }

        unsigned long *stack_pointer;
        unsigned long *frame_pointer;

        // For the currently running process, use the actual esp and ebp
        if (proc->pstate == PRCURR) {
            stack_pointer = esp;
            frame_pointer = ebp;
        } else {
            stack_pointer = (unsigned long *)proc->pesp;
            frame_pointer = stack_pointer + 2; // Adjust for context switch
        }

        kprintf("\n\nProcess [%s]",proc->pname);
        kprintf("\n     pid:%d",i);
        kprintf("\n     priority:%d",proc->pprio);
        kprintf("\n     base:0x%08x",proc->pbase);
        kprintf("\n     limit:%d", proc->pstklen);
        kprintf("\n     len:0x%08x\n",proc->plimit);
        kprintf("\n     pointer:0x%08x",(unsigned long)stack_pointer);

    }
}
