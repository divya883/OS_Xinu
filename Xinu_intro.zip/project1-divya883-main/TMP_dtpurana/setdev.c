/* setdev.c - setdev */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include "lab0.h"

/*------------------------------------------------------------------------
 *  setdev  -  set the two device entries in the process table entry
 *------------------------------------------------------------------------
 */
int isTracingEnabled;
SYSCALL	setdev(int pid, int dev1, int dev2)
{	
	//unsigned long ctr1000;
	unsigned long timeTaken = ctr1000;
	short	*nxtdev;

	if (isbadpid(pid)){
		if(isTracingEnabled) {
			timeTaken = ctr1000 - timeTaken;
			updateSyscallAccounting(13, timeTaken);
		}
		return(SYSERR);
	}
	nxtdev = (short *) proctab[pid].pdevs;
	*nxtdev++ = dev1;
	*nxtdev = dev2;

	if(isTracingEnabled) {
			timeTaken = ctr1000 - timeTaken;
			updateSyscallAccounting(13, timeTaken);
	}
	return(OK);
}
