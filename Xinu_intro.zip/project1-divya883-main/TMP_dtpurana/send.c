/* send.c - send */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include "lab0.h"

/*------------------------------------------------------------------------
 *  send  --  send a message to another process
 *------------------------------------------------------------------------
 */
int isTracingEnabled;
SYSCALL	send(int pid, WORD msg)
{	
	//unsigned long ctr1000;
	unsigned long timeTaken = ctr1000;

	STATWORD ps;    
	struct	pentry	*pptr;

	disable(ps);
	if (isbadpid(pid) || ( (pptr= &proctab[pid])->pstate == PRFREE)
	   || pptr->phasmsg != 0) {
		restore(ps);
		if(isTracingEnabled) {
			timeTaken = ctr1000 - timeTaken;
			updateSyscallAccounting(12, timeTaken);
		}
		return(SYSERR);
	}
	pptr->pmsg = msg;
	pptr->phasmsg = TRUE;
	if (pptr->pstate == PRRECV)	/* if receiver waits, start it	*/
		ready(pid, RESCHYES);
	else if (pptr->pstate == PRTRECV) {
		unsleep(pid);
		ready(pid, RESCHYES);
	}
	restore(ps);

	if(isTracingEnabled) {
			timeTaken = ctr1000 - timeTaken;
			updateSyscallAccounting(12, timeTaken);
	}

	return(OK);
}
