To compile:
make 
(OR)
gcc -O0 defrag.c -o defrag

To run:
./defrag images_frag/disk_frag_x where x = 1, 2, 3 

- output is saved in "disk_defrag" in the same folder.

To check the difference or match percentage:
python diff.py disk_defrag images_defrag/disk_defrag_x where x = 1, 2, 3