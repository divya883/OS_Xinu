#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Adjusted constants to different naming style */
#define DIRECT_BLOCK_COUNT 10
#define INDIRECT_BLOCK_COUNT 4
#define OUTPUT_IMAGE_NAME "disk_defrag"

/* 
   This structure represents the superblock of the filesystem.
   It holds essential metadata about the file system layout. 
*/
typedef struct SuperBlockInfo {
    int     block_size;      // Size of each data block in bytes
    int     inode_start;     // Offset (in blocks) where inodes start
    int     data_start;      // Offset (in blocks) where data blocks start
    int     swap_start;      // Offset (in blocks) where swap area starts
    int     first_free_inode;// Index of the first free inode
    int     first_free_block;// Index of the first free data block
} SuperBlock;

/*
   This structure represents an inode. Each inode holds pointers to data blocks,
   along with file ownership and timing metadata.
*/
typedef struct INodeStruct {
    int next_inode_idx;
    int protection;
    int link_count;
    int file_size;
    int user_id;
    int group_id;
    int ctime;
    int mtime;
    int atime;
    int direct_blocks[DIRECT_BLOCK_COUNT];   // Direct block pointers
    int indirect_blocks[INDIRECT_BLOCK_COUNT]; // Indirect block pointers
    int double_indirect_block;   // Double-indirect pointer
    int triple_indirect_block;   // Triple-indirect pointer
} INode;

/*
   An auxiliary structure to track per-inode data block info. In this implementation,
   it's not used extensively, but is kept to preserve the logic and data flow.
*/
typedef struct INodeDataTracking {
    int *block_list;
    int blocks_count;
    int offset_in_file;
} INodeMeta;

/* Functions to read and write filesystem structures */

/* Move file pointer and read the superblock from the given image file */
static void fetchSuperBlockInfo(FILE *fs_img, SuperBlock *sb) {
    fseek(fs_img, 512, SEEK_SET); 
    fread(sb, sizeof(SuperBlock), 1, fs_img);
}

/* Move file pointer and write the superblock to the given image file */
static void storeSuperBlockInfo(FILE *fs_img, SuperBlock *sb) {
    fseek(fs_img, 512, SEEK_SET); 
    fwrite(sb, sizeof(SuperBlock), 1, fs_img);
}

/* Obtain inode array from the filesystem image */
static void extractINodes(FILE *fs_img, int inode_offset, int blk_sz, int inode_count, INode *node_array) {
    fseek(fs_img, 1024 + (inode_offset * blk_sz), SEEK_SET);
    fread(node_array, sizeof(INode)*inode_count, 1, fs_img);
}

/* Write the updated inode array back into the filesystem image */
static void placeINodes(FILE *fs_img, int inode_offset, int blk_sz, int inode_count, INode *node_array) {
    fseek(fs_img, 1024 + (inode_offset * blk_sz), SEEK_SET);
    fwrite(node_array, sizeof(INode)*inode_count, 1, fs_img);
}

/* Read a block holding a list of indirect block indexes */
static void loadIndirectionBlock(FILE *fs_img, int data_start, int block_idx, int blk_sz, int *buffer) {
    fseek(fs_img, 1024 + (data_start * blk_sz) + (block_idx * blk_sz), SEEK_SET);
    fread(buffer, blk_sz, 1, fs_img);
}

/* Write a block of indirect block indexes back to the image */
static void writeIndirectionBlock(FILE *fs_img, int data_start, int block_idx, int blk_sz, int *buffer) {
    fseek(fs_img, 1024 + (data_start * blk_sz) + (block_idx * blk_sz), SEEK_SET);
    fwrite(buffer, blk_sz, 1, fs_img);
}

/* Extract raw data from a single data block */
static void grabDataBlock(FILE *fs_img, int data_start, int blk_num, int blk_sz, unsigned char *temp_buffer) {
    fseek(fs_img, 1024 + (data_start * blk_sz) + (blk_num * blk_sz), SEEK_SET);
    fread(temp_buffer, blk_sz, 1, fs_img);
}

/* Write data to a single data block */
static void recordDataBlock(FILE *fs_img, int data_start, int blk_num, int blk_sz, unsigned char *temp_buffer) {
    fseek(fs_img, 1024 + (data_start * blk_sz) + (blk_num * blk_sz), SEEK_SET);
    fwrite(temp_buffer, blk_sz, 1, fs_img);
}

/* 
   Recursively handle single-indirect blocks: read their entries, relocate each referenced data block,
   and write them to the new image. Update the indirect block mapping accordingly.
*/
static void processSingleIndirect(FILE *source, FILE *destination,
                                  int data_start, int block_idx, SuperBlock *sb, int *free_block_counter) {
    int blk_sz = sb->block_size;
    int entries_count = blk_sz / sizeof(int);
    int *entries = (int*)calloc(entries_count, sizeof(int));

    loadIndirectionBlock(source, data_start, block_idx, blk_sz, entries);

    for (int i = 0; i < entries_count; i++) {
        if (entries[i] > -1) {
            unsigned char *temp = (unsigned char*)calloc(blk_sz, 1);
            grabDataBlock(source, data_start, entries[i], blk_sz, temp);
            recordDataBlock(destination, data_start, *free_block_counter, blk_sz, temp);
            entries[i] = (*free_block_counter)++;
            free(temp);
        }
    }

    writeIndirectionBlock(destination, data_start, block_idx, blk_sz, entries);
    free(entries);
}

/* 
   Handle double-indirect blocks: 
   Each entry in a double-indirect block points to a single-indirect block.
   We allocate a new block index for the relocated block and call processSingleIndirect for each.
*/
static void processDoubleIndirect(FILE *source, FILE *destination,
                                  int data_start, int block_idx, SuperBlock *sb, int *free_block_counter) {
    int blk_sz = sb->block_size;
    int entries_count = blk_sz / sizeof(int);
    int *double_entries = (int*)calloc(entries_count, sizeof(int));

    loadIndirectionBlock(source, data_start, block_idx, blk_sz, double_entries);

    for (int i = 0; i < entries_count; i++) {
        if (double_entries[i] > -1) {
            int new_allocated_block = (*free_block_counter)++;
            processSingleIndirect(source, destination, data_start, double_entries[i], sb, free_block_counter);
            double_entries[i] = new_allocated_block;
        }
    }

    writeIndirectionBlock(destination, data_start, block_idx, blk_sz, double_entries);
    free(double_entries);
}

/*
   Handle triple-indirect blocks:
   Each entry points to a double-indirect block. Similar to the double-indirect handling,
   we reallocate and update pointers accordingly.
*/
static void processTripleIndirect(FILE *source, FILE *destination,
                                  int data_start, int block_idx, SuperBlock *sb, int *free_block_counter) {
    int blk_sz = sb->block_size;
    int entries_count = blk_sz / sizeof(int);
    int *triple_entries = (int*)calloc(entries_count, sizeof(int));

    loadIndirectionBlock(source, data_start, block_idx, blk_sz, triple_entries);

    for (int i = 0; i < entries_count; i++) {
        if (triple_entries[i] > -1) {
            int newly_allocated = (*free_block_counter)++;
            processDoubleIndirect(source, destination, data_start, triple_entries[i], sb, free_block_counter);
            triple_entries[i] = newly_allocated;
        }
    }

    writeIndirectionBlock(destination, data_start, block_idx, blk_sz, triple_entries);
    free(triple_entries);
}

/* 
   This is the main defragmentation routine:
   It reads all inodes, then for each inode:
     - Relocates direct blocks into a continuous sequence starting from the first free block.
     - Relocates single-indirect, double-indirect, and triple-indirect blocks similarly.
   After adjustments, updates the superblock and writes everything to the new image.
*/
static void performDefragmentation(FILE *source, FILE *destination, SuperBlock *sb) {
    int inode_count = (sb->data_start - sb->inode_start) * sb->block_size / sizeof(INode);
    INode *all_inodes = (INode*)malloc(sizeof(INode)*inode_count);

    // Retrieve inode array
    extractINodes(source, sb->inode_start, sb->block_size, inode_count, all_inodes);

    INodeMeta *node_meta = (INodeMeta*)malloc(sizeof(INodeMeta)*inode_count);
    int free_block_ptr = 0;

    // Process each inode to relocate data blocks
    for (int i_node_idx = 0; i_node_idx < inode_count; i_node_idx++) {
        node_meta[i_node_idx].block_list = (int*)malloc(1000 * sizeof(int));
        node_meta[i_node_idx].blocks_count = 0; 
        node_meta[i_node_idx].offset_in_file = 0; 

        if (all_inodes[i_node_idx].link_count <= 0) {
            // Unused inode, skip relocation
            continue;
        }

        // Relocate direct blocks
        for (int d_i = 0; d_i < DIRECT_BLOCK_COUNT; d_i++) {
            if (all_inodes[i_node_idx].direct_blocks[d_i] == -1) {
                break;
            }
            unsigned char *data_buf = (unsigned char*)calloc(sb->block_size, 1);
            grabDataBlock(source, sb->data_start, all_inodes[i_node_idx].direct_blocks[d_i], sb->block_size, data_buf);
            recordDataBlock(destination, sb->data_start, free_block_ptr, sb->block_size, data_buf);
            all_inodes[i_node_idx].direct_blocks[d_i] = free_block_ptr++;
            free(data_buf);
        }

        // Relocate single-indirect blocks
        for (int i_i = 0; i_i < INDIRECT_BLOCK_COUNT; i_i++) {
            if (all_inodes[i_node_idx].indirect_blocks[i_i] == -1) {
                break;
            }
            int new_indirect_block = free_block_ptr++;
            processSingleIndirect(source, destination, sb->data_start, all_inodes[i_node_idx].indirect_blocks[i_i], sb, &free_block_ptr);
            all_inodes[i_node_idx].indirect_blocks[i_i] = new_indirect_block;
        }

        // Relocate double-indirect block
        if (all_inodes[i_node_idx].double_indirect_block != -1) {
            int new_double = free_block_ptr++;
            processDoubleIndirect(source, destination, sb->data_start, all_inodes[i_node_idx].double_indirect_block, sb, &free_block_ptr);
            all_inodes[i_node_idx].double_indirect_block = new_double;
        }

        // Relocate triple-indirect block
        if (all_inodes[i_node_idx].triple_indirect_block != -1) {
            int new_triple = free_block_ptr++;
            processTripleIndirect(source, destination, sb->data_start, all_inodes[i_node_idx].triple_indirect_block, sb, &free_block_ptr);
            all_inodes[i_node_idx].triple_indirect_block = new_triple;
        }
    }

    // Update the free_block pointer in the superblock
    sb->first_free_block = free_block_ptr;

    // Copy boot block from old image to the new image
    unsigned char *bootloader_chunk = (unsigned char*)malloc(512);
    fseek(source, 0L, SEEK_SET);
    fread(bootloader_chunk, 512, 1, source);
    fseek(destination, 0L, SEEK_SET);
    fwrite(bootloader_chunk, 512, 1, destination);

    // Write updated superblock and inode list
    storeSuperBlockInfo(destination, sb);
    placeINodes(destination, sb->inode_start, sb->block_size, inode_count, all_inodes);

    free(bootloader_chunk);
    free(all_inodes);

    for (int clean_idx = 0; clean_idx < inode_count; clean_idx++) {
        free(node_meta[clean_idx].block_list);
    }
    free(node_meta);
}

/*
   Program entry point:
   Expects a single command-line argument representing the input filesystem image filename.
   It will create an output file named "disk_defrag" containing the defragmented filesystem.
*/
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_image>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *input_file = argv[1];
    FILE *old_image = fopen(input_file, "rb");
    if (old_image == NULL) {
        perror("Failed to open the specified input image file.");
        return EXIT_FAILURE;
    }

    FILE *new_image = fopen(OUTPUT_IMAGE_NAME, "w+b");
    fseek(new_image, 0L, SEEK_SET);

    SuperBlock sb_data;
    fetchSuperBlockInfo(old_image, &sb_data);

    performDefragmentation(old_image, new_image, &sb_data);

    fclose(old_image);
    fclose(new_image);

    return EXIT_SUCCESS;
}