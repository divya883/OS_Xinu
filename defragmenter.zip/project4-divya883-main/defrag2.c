#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#pragma pack(push, 1)
struct superblock {
    uint32_t blocksize;    /* size of blocks in bytes */
    uint32_t inode_offset; /* offset of inode region in blocks */
    uint32_t data_offset;  /* data region offset in blocks */
    uint32_t swap_offset;  /* swap region offset in blocks */
    uint32_t free_inode;   /* head of free inode list */
    uint32_t free_block;   /* head of free block list */
};
#pragma pack(pop)

#define N_DBLOCKS 10
#define N_IBLOCKS 4
#define INVALID_BLOCK 0xFFFFFFFF
#define OUTPUT_FILE_NAME "disk_defrag"

#pragma pack(push, 1)
struct inode {
    uint32_t next_inode;         /* Next free inode */
    uint32_t protect;            /* Protection flags */
    uint32_t nlink;              /* Number of links */
    uint32_t size;               /* File size in bytes */
    uint32_t uid;                /* Owner user ID */
    uint32_t gid;                /* Owner group ID */
    uint32_t ctime;              /* Creation time */
    uint32_t mtime;              /* Modification time */
    uint32_t atime;              /* Access time */
    uint32_t dblocks[N_DBLOCKS]; /* Direct block pointers */
    uint32_t iblocks[N_IBLOCKS]; /* Indirect block pointers */
    uint32_t i2block;            /* Double indirect block pointer */
    uint32_t i3block;            /* Triple indirect block pointer */
};
#pragma pack(pop)

uint32_t read_little_endian_uint32(const unsigned char *buffer) {
    return (uint32_t)buffer[0] |
           ((uint32_t)buffer[1] << 8) |
           ((uint32_t)buffer[2] << 16) |
           ((uint32_t)buffer[3] << 24);
}

void write_little_endian_uint32(unsigned char *buffer, uint32_t value) {
    buffer[0] = (unsigned char)(value & 0xFF);
    buffer[1] = (unsigned char)((value >> 8) & 0xFF);
    buffer[2] = (unsigned char)((value >> 16) & 0xFF);
    buffer[3] = (unsigned char)((value >> 24) & 0xFF);
}

// Global variables
unsigned char *disk_buffer = NULL;
uint64_t data_start;
struct superblock sb;
uint32_t next_free_block = 0;
uint32_t total_data_blocks = 0;

void relocate_data_block(uint32_t old_block_idx, uint32_t new_block_idx) {
    if (old_block_idx >= total_data_blocks || new_block_idx >= total_data_blocks) {
        fprintf(stderr, "Error: Block index out of bounds (old: %u, new: %u)\n", old_block_idx, new_block_idx);
        exit(EXIT_FAILURE);
    }
    unsigned char *src = disk_buffer + data_start + (old_block_idx * sb.blocksize);
    unsigned char *dest = disk_buffer + data_start + (new_block_idx * sb.blocksize);
    memcpy(dest, src, sb.blocksize);
    memset(src, 0, sb.blocksize); // Clear the source block
}

// uint32_t process_indirect_block(uint32_t old_block_idx, size_t *blocks_processed, size_t blocks_needed) {
//     if (old_block_idx >= total_data_blocks) {
//         fprintf(stderr, "Warning: Skipping invalid indirect block index %u\n", old_block_idx);
//         return INVALID_BLOCK; // Skip invalid blocks
//     }

//     uint32_t new_block_idx = next_free_block++;
//     relocate_data_block(old_block_idx, new_block_idx);

//     unsigned char *indirect_block = disk_buffer + data_start + (new_block_idx * sb.blocksize);

//     size_t pointers_per_block = sb.blocksize / 4;
//     size_t blocks_remaining = blocks_needed - *blocks_processed;
//     size_t entries_to_process = (blocks_remaining < pointers_per_block) ? blocks_remaining : pointers_per_block;
//     uint32_t i;
//     for (i = 0; i < entries_to_process; i++) {
//         uint32_t old_data_block = read_little_endian_uint32(indirect_block + (i * 4));

//         if (old_data_block != INVALID_BLOCK) {
//             if (old_data_block >= total_data_blocks) {
//                 fprintf(stderr, "Warning: Skipping invalid data block index %u in indirect block %u\n", old_data_block, old_block_idx);
//                 write_little_endian_uint32(indirect_block + (i * 4), INVALID_BLOCK);
//                 continue;
//             }

//             uint32_t new_data_block_idx = next_free_block++;
//             relocate_data_block(old_data_block, new_data_block_idx);
//             write_little_endian_uint32(indirect_block + (i * 4), new_data_block_idx);
//             (*blocks_processed)++;
//         } else {
//             write_little_endian_uint32(indirect_block + (i * 4), INVALID_BLOCK);
//             break;
//         }
//     }

//     return new_block_idx;
// }

uint32_t process_indirect_block(uint32_t old_block_idx, size_t *blocks_processed, size_t blocks_needed) {
    // Check if the old block index is valid
    if (old_block_idx >= total_data_blocks) {
        fprintf(stderr, "Warning: Skipping invalid indirect block index %u\n", old_block_idx);
        return INVALID_BLOCK;
    }

    // 1. Allocate a new block index for the indirect block and relocate it
    uint32_t new_block_idx = next_free_block++;
    relocate_data_block(old_block_idx, new_block_idx);

    // Pointer to the newly placed indirect block in the output image
    unsigned char *indirect_block = disk_buffer + data_start + (new_block_idx * sb.blocksize);

    // Calculate how many pointers we can have per indirect block
    size_t pointers_per_block = sb.blocksize / 4;

    // Calculate how many blocks we still need to process for this file
    size_t blocks_remaining = blocks_needed - *blocks_processed;
    size_t entries_to_process = (blocks_remaining < pointers_per_block) ? blocks_remaining : pointers_per_block;

    // 2. Iterate over each entry in the indirect block
    for (size_t i = 0; i < entries_to_process; i++) {
        uint32_t old_data_block = read_little_endian_uint32(indirect_block + (i * 4));

        // If we hit an invalid block, mark it and stop processing further entries
        if (old_data_block == INVALID_BLOCK) {
            write_little_endian_uint32(indirect_block + (i * 4), INVALID_BLOCK);
            break;
        }

        // Validate the old data block index
        if (old_data_block >= total_data_blocks) {
            fprintf(stderr, "Warning: Skipping invalid data block index %u in indirect block %u\n", old_data_block, old_block_idx);
            write_little_endian_uint32(indirect_block + (i * 4), INVALID_BLOCK);
            continue;
        }

        // 3. Place each data block contiguously after the indirect block
        // Since we've already used 'new_block_idx' for the indirect block itself,
        // the next available block in the new image will be 'next_free_block'.
        uint32_t new_data_block_idx = next_free_block++;
        relocate_data_block(old_data_block, new_data_block_idx);

        // Update the pointer in the indirect block to point to the new data block location
        write_little_endian_uint32(indirect_block + (i * 4), new_data_block_idx);

        // Increment the count of processed blocks
        (*blocks_processed)++;
    }

    return new_block_idx;
}



void print_inode_data(uint64_t inode_start, size_t inode_count, size_t inode_size) {
    printf("=== Superblock Information ===\n");
    printf("Block Size: %u\n", sb.blocksize);
    printf("Inode Offset (blocks): %u\n", sb.inode_offset);
    printf("Data Offset (blocks): %u\n", sb.data_offset);
    printf("Swap Offset (blocks): %u\n", sb.swap_offset);
    printf("Free Inode: %u\n", sb.free_inode);
    printf("Free Block: %u\n", sb.free_block);
    printf("===============================\n\n");

    for (size_t i = 0; i < inode_count; i++) {
        unsigned char *inode_data = disk_buffer + inode_start + (i * inode_size);
        uint32_t nlink = read_little_endian_uint32(inode_data + 8);

        // Only print inodes with valid links
        if (nlink > 0) {
            printf("Inode %zu:\n", i);
            printf("  Protection Flags: %u\n", read_little_endian_uint32(inode_data + 4));
            printf("  Number of Links: %u\n", nlink);
            printf("  File Size: %u bytes\n", read_little_endian_uint32(inode_data + 12));
            printf("  Owner UID: %u\n", read_little_endian_uint32(inode_data + 16));
            printf("  Owner GID: %u\n", read_little_endian_uint32(inode_data + 20));
            printf("  Creation Time: %u\n", read_little_endian_uint32(inode_data + 24));
            printf("  Modification Time: %u\n", read_little_endian_uint32(inode_data + 28));
            printf("  Access Time: %u\n", read_little_endian_uint32(inode_data + 32));

            printf("  Direct Blocks:\n");
            for (size_t j = 0; j < N_DBLOCKS; j++) {
                uint32_t block = read_little_endian_uint32(inode_data + 36 + (j * 4));
                if (block != INVALID_BLOCK) {
                    printf("    Block %zu: %u\n", j, block);
                }
            }

            printf("  Indirect Blocks:\n");
            for (size_t j = 0; j < N_IBLOCKS; j++) {
                uint32_t block = read_little_endian_uint32(inode_data + 76 + (j * 4));
                if (block != INVALID_BLOCK) {
                    printf("    Indirect Block %zu: %u\n", j, block);
                }
            }

            uint32_t i2block = read_little_endian_uint32(inode_data + 92);
            if (i2block != INVALID_BLOCK) {
                printf("  Double Indirect Block: %u\n", i2block);
            }

            uint32_t i3block = read_little_endian_uint32(inode_data + 96);
            if (i3block != INVALID_BLOCK) {
                printf("  Triple Indirect Block: %u\n", i3block);
            }
            printf("-------------------------------\n");
        }
    }
}
/*
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <disk_image>\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *in_file, *out_file;
    size_t disk_size;

    in_file = fopen(argv[1], "rb");
    if (!in_file) {
        perror("Failed to open disk image");
        return EXIT_FAILURE;
    }

    fseek(in_file, 0, SEEK_END);
    disk_size = ftell(in_file);
    rewind(in_file);

    disk_buffer = (unsigned char *)malloc(disk_size);
    if (!disk_buffer) {
        fprintf(stderr, "Failed to allocate memory for disk image\n");
        fclose(in_file);
        return EXIT_FAILURE;
    }

    fread(disk_buffer, 1, disk_size, in_file);
    fclose(in_file);


    sb.blocksize = read_little_endian_uint32(disk_buffer + 512);
    sb.inode_offset = read_little_endian_uint32(disk_buffer + 512 + 4);
    sb.data_offset = read_little_endian_uint32(disk_buffer + 512 + 8);
    sb.swap_offset = read_little_endian_uint32(disk_buffer + 512 + 12);
    sb.free_inode = read_little_endian_uint32(disk_buffer + 512 + 16);
    sb.free_block = read_little_endian_uint32(disk_buffer + 512 + 20);

    uint64_t inode_start = sb.blocksize * (sb.inode_offset + 2);
    data_start = sb.blocksize * (sb.data_offset + 2);

    size_t inode_size = sizeof(struct inode);
    size_t inode_count = ((sb.data_offset - sb.inode_offset) * sb.blocksize) / inode_size;

    total_data_blocks = sb.swap_offset - sb.data_offset;
    print_inode_data(inode_start, inode_count, inode_size);

    printf("\nDefragmenting Data Region:\n");

    next_free_block = 0;

    size_t i,j;
    for (i = 0; i < inode_count; i++) {
        unsigned char *inode_data = disk_buffer + inode_start + (i * inode_size);
        uint32_t nlink = read_little_endian_uint32(inode_data + 8);

        if (nlink > 0) {
            size_t file_size = read_little_endian_uint32(inode_data + 12);
            size_t blocks_needed = (file_size + sb.blocksize - 1) / sb.blocksize;

            size_t blocks_processed = 0;

            for (j = 0; j < N_DBLOCKS && blocks_processed < blocks_needed; j++) {
                uint32_t old_block = read_little_endian_uint32(inode_data + 36 + (j * 4));
                if (old_block != INVALID_BLOCK) {
                    uint32_t new_block = next_free_block++;
                    relocate_data_block(old_block, new_block);
                    write_little_endian_uint32(inode_data + 36 + (j * 4), new_block);
                    printf("Inode %zu Direct Block %zu: %u -> %u\n", i, j, old_block, new_block);
                    blocks_processed++;
                }
            }

            for (j = 0; j < N_IBLOCKS && blocks_processed < blocks_needed; j++) {
                uint32_t old_indirect = read_little_endian_uint32(inode_data + 76 + (j * 4));

                if (old_indirect != INVALID_BLOCK) {
                    uint32_t new_indirect = process_indirect_block(old_indirect, &blocks_processed, blocks_needed);
                    write_little_endian_uint32(inode_data + 76 + (j * 4), new_indirect);
                    printf("Inode %zu Indirect Block %zu: %u -> %u\n", i, j, old_indirect, new_indirect);
                }
            }
        }
    }

    printf("\nDefragmentation Complete.\n");

    out_file = fopen(OUTPUT_FILE_NAME, "wb");
    if (!out_file) {
        perror("Failed to open output file");
        free(disk_buffer);
        return EXIT_FAILURE;
    }

    fwrite(disk_buffer, 1, disk_size, out_file);
    fclose(out_file);

    printf("Defragmentation completed successfully. Output: %s\n", OUTPUT_FILE_NAME);

    free(disk_buffer);
    return EXIT_SUCCESS;
}
*/
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <disk_image>\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *in_file, *out_file;
    size_t disk_size;

    in_file = fopen(argv[1], "rb");
    if (!in_file) {
        perror("Failed to open disk image");
        return EXIT_FAILURE;
    }

    fseek(in_file, 0, SEEK_END);
    disk_size = ftell(in_file);
    rewind(in_file);

    disk_buffer = (unsigned char *)malloc(disk_size);
    if (!disk_buffer) {
        fprintf(stderr, "Failed to allocate memory for disk image\n");
        fclose(in_file);
        return EXIT_FAILURE;
    }

    fread(disk_buffer, 1, disk_size, in_file);
    fclose(in_file);

    // Read superblock information
    sb.blocksize = read_little_endian_uint32(disk_buffer + 512);
    sb.inode_offset = read_little_endian_uint32(disk_buffer + 512 + 4);
    sb.data_offset = read_little_endian_uint32(disk_buffer + 512 + 8);
    sb.swap_offset = read_little_endian_uint32(disk_buffer + 512 + 12);
    sb.free_inode = read_little_endian_uint32(disk_buffer + 512 + 16);
    sb.free_block = read_little_endian_uint32(disk_buffer + 512 + 20);

    uint64_t inode_start = sb.blocksize * (sb.inode_offset + 2);
    data_start = sb.blocksize * (sb.data_offset + 2);

    size_t inode_size = sizeof(struct inode);
    size_t inode_count = ((sb.data_offset - sb.inode_offset) * sb.blocksize) / inode_size;

    total_data_blocks = sb.swap_offset - sb.data_offset;

    // Print disk layout before defragmentation
    printf("\n==== Disk Layout Before Defragmentation ====\n");
    print_inode_data(inode_start, inode_count, inode_size);

    printf("\nDefragmenting Data Region:\n");

    next_free_block = 0;

    size_t i, j;
    for (i = 0; i < inode_count; i++) {
        unsigned char *inode_data = disk_buffer + inode_start + (i * inode_size);
        uint32_t nlink = read_little_endian_uint32(inode_data + 8);

        if (nlink > 0) {
            size_t file_size = read_little_endian_uint32(inode_data + 12);
            size_t blocks_needed = (file_size + sb.blocksize - 1) / sb.blocksize;

            size_t blocks_processed = 0;

            for (j = 0; j < N_DBLOCKS && blocks_processed < blocks_needed; j++) {
                uint32_t old_block = read_little_endian_uint32(inode_data + 36 + (j * 4));
                if (old_block != INVALID_BLOCK) {
                    uint32_t new_block = next_free_block++;
                    relocate_data_block(old_block, new_block);
                    write_little_endian_uint32(inode_data + 36 + (j * 4), new_block);
                    //printf("Inode %zu Direct Block %zu: %u -> %u\n", i, j, old_block, new_block);
                    blocks_processed++;
                }
            }

            for (j = 0; j < N_IBLOCKS && blocks_processed < blocks_needed; j++) {
                uint32_t old_indirect = read_little_endian_uint32(inode_data + 76 + (j * 4));

                if (old_indirect != INVALID_BLOCK) {
                    uint32_t new_indirect = process_indirect_block(old_indirect, &blocks_processed, blocks_needed);
                    write_little_endian_uint32(inode_data + 76 + (j * 4), new_indirect);
                    //printf("Inode %zu Indirect Block %zu: %u -> %u\n", i, j, old_indirect, new_indirect);
                }
            }
        }
    }

    printf("\n==== Disk Layout After Defragmentation ====\n");
    print_inode_data(inode_start, inode_count, inode_size);

    printf("\nDefragmentation Complete.\n");

    out_file = fopen(OUTPUT_FILE_NAME, "wb");
    if (!out_file) {
        perror("Failed to open output file");
        free(disk_buffer);
        return EXIT_FAILURE;
    }

    fwrite(disk_buffer, 1, disk_size, out_file);
    fclose(out_file);

    printf("Defragmentation completed successfully. Output: %s\n", OUTPUT_FILE_NAME);

    free(disk_buffer);
    return EXIT_SUCCESS;
}
